(function(window, undefined) {

  var jimLinks = {
    "24190c50-1a32-46a0-b83e-608550c34bb0" : {
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ]
    },
    "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d" : {
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ]
    },
    "0c01920d-1e22-4c8d-807e-a74c441d4377" : {
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ]
    },
    "93e41e19-9d0b-4e4d-bf32-9d4830c407bb" : {
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ]
    },
    "6075582e-378c-4fdf-adac-6eee1c63827e" : {
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ]
    },
    "2126e8ba-dd41-46f5-a839-e6a07337c6cb" : {
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Ellipse_1" : [
        "2126e8ba-dd41-46f5-a839-e6a07337c6cb"
      ],
      "Image_35" : [
        "2126e8ba-dd41-46f5-a839-e6a07337c6cb"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ],
      "Rectangle_4" : [
        "0c01920d-1e22-4c8d-807e-a74c441d4377"
      ]
    },
    "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a" : {
      "Text_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_1" : [
        "6075582e-378c-4fdf-adac-6eee1c63827e"
      ],
      "Text_2" : [
        "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"
      ],
      "Text_3" : [
        "24190c50-1a32-46a0-b83e-608550c34bb0"
      ],
      "Text_4" : [
        "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"
      ],
      "Text_9" : [
        "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);