	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Rectangle_1", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Bg_7", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_7", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Text", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Paragraph_9", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Ellipse_11", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_11", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5"]; 

	widgets.descriptionMap[["s-Image_42", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Image_42", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["User icon", "s-Image_42"]; 

	widgets.descriptionMap[["s-Bg_8", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_8", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Text_10", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Paragraph_10", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Ellipse_12", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_12", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_1"]; 

	widgets.descriptionMap[["s-Image_43", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Image_43", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["User icon", "s-Image_43"]; 

	widgets.descriptionMap[["s-Bg_9", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_9", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Text_12", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_12", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Paragraph_11", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Ellipse_13", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_13", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Testimonial 5", "s-Testimonial-5_2"]; 

	widgets.descriptionMap[["s-Image_44", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Image_44", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["User icon", "s-Image_44"]; 

	widgets.descriptionMap[["s-Rectangle_2", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "24190c50-1a32-46a0-b83e-608550c34bb0"]] = ["Twitter", "s-Image_4"]; 

	widgets.descriptionMap[["s-Rectangle_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_3", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Contact 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Button dark", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Input_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Contact 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_2", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Contact 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_3", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Contact 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Paragraph 1", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Text_10", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Title 1", "s-Text_10"]; 

	widgets.descriptionMap[["s-Paragraph_2", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Paragraph 1", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Rectangle_5", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Contact 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Image_6", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Pin icon", "s-Image_6"]; 

	widgets.descriptionMap[["s-Image_7", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Mail icon", "s-Image_7"]; 

	widgets.descriptionMap[["s-Rectangle_2", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "f4d5e8a2-48b3-4216-8d7c-1431fb2c035d"]] = ["Twitter", "s-Image_4"]; 

	widgets.descriptionMap[["s-Rectangle_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_3", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Sign up form 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Button dark", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Input_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Sign up form 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_2", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Sign up form 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_3", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Sign up form 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_4", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Sign up form 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_10", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Title 1", "s-Text_10"]; 

	widgets.descriptionMap[["s-Rectangle_2", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Twitter", "s-Image_4"]; 

	widgets.descriptionMap[["s-Callout_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ""; 

			widgets.rootWidgetMap[["s-Callout_1", "0c01920d-1e22-4c8d-807e-a74c441d4377"]] = ["Callout", "s-Callout_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Bg", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Rectangle_3", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Rectangle_4", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Rectangle_5", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Title", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Paragraph", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Image_6", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Chev Right", "s-Image_6"]; 

	widgets.descriptionMap[["s-Image_7", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Chev Left", "s-Image_7"]; 

	widgets.descriptionMap[["s-Text_10", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Portfolio 1", "s-Portfolio-1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "93e41e19-9d0b-4e4d-bf32-9d4830c407bb"]] = ["Twitter", "s-Image_4"]; 

	widgets.descriptionMap[["s-Rectangle_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Bg", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Testimonial 6", "s-Testimonial_6"]; 

	widgets.descriptionMap[["s-Text", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Testimonial 6", "s-Testimonial_6"]; 

	widgets.descriptionMap[["s-Paragraph", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Testimonial 6", "s-Testimonial_6"]; 

	widgets.descriptionMap[["s-Rectangle_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Image_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Image_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Image_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Paragraph_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Line_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Line_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_10", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_12", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_12", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_13", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_13", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_14", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_14", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_15", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_15", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Panel_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Text_16", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Feature menu slider", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Twitter", "s-Image_4"]; 

	widgets.descriptionMap[["s-Bg_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Large feature 1", "s-Feature-2"]; 

	widgets.descriptionMap[["s-Rectangle_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Large feature 1", "s-Feature-2"]; 

	widgets.descriptionMap[["s-Ellipse_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Large feature 1", "s-Feature-2"]; 

	widgets.descriptionMap[["s-Ellipse_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Large feature 1", "s-Feature-2"]; 

	widgets.descriptionMap[["s-Ellipse_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Large feature 1", "s-Feature-2"]; 

	widgets.descriptionMap[["s-Rectangle_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Circle", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Circle", "s-Circle"]; 

	widgets.descriptionMap[["s-Rectangle_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Rounded rectangle", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Image_39", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Clear filled", "s-Image_39"]; 

	widgets.descriptionMap[["s-Circle_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Circle_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Circle", "s-Circle_1"]; 

	widgets.descriptionMap[["s-Rectangle_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Line_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Line", "s-Line_4"]; 

	widgets.descriptionMap[["s-Text_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_6"]; 

	widgets.descriptionMap[["s-Line_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Line", "s-Line_5"]; 

	widgets.descriptionMap[["s-Rectangle_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Rounded rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Dashed-rounded-rectangle", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Dashed-rounded-rectangle", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dashed rounded rectangle", "s-Dashed-rounded-rectangle"]; 

	widgets.descriptionMap[["s-Button_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Line_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Vertical Sequence Flow", "s-Line_3"]; 

	widgets.descriptionMap[["s-Text_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_7"]; 

	widgets.descriptionMap[["s-Text_17", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_17", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_17"]; 

	widgets.descriptionMap[["s-Text_18", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_18", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_18"]; 

	widgets.descriptionMap[["s-Text_19", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_19", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_19"]; 

	widgets.descriptionMap[["s-Dashed-rounded-rectangle_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Dashed-rounded-rectangle_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dashed rounded rectangle", "s-Dashed-rounded-rectangle_1"]; 

	widgets.descriptionMap[["s-Button_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Text_20", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_20", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_20"]; 

	widgets.descriptionMap[["s-Text_21", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_21", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_21"]; 

	widgets.descriptionMap[["s-Text_22", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_22", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_22"]; 

	widgets.descriptionMap[["s-Text_23", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_23", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_23"]; 

	widgets.descriptionMap[["s-Dashed-rounded-rectangle_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Dashed-rounded-rectangle_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dashed rounded rectangle", "s-Dashed-rounded-rectangle_2"]; 

	widgets.descriptionMap[["s-Button_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Text_24", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_24", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_24"]; 

	widgets.descriptionMap[["s-Text_25", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_25", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_25"]; 

	widgets.descriptionMap[["s-Text_26", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_26", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_26"]; 

	widgets.descriptionMap[["s-Text_27", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_27", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_27"]; 

	widgets.descriptionMap[["s-Line_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Vertical Sequence Flow", "s-Line_6"]; 

	widgets.descriptionMap[["s-Line_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Line_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Vertical Sequence Flow", "s-Line_7"]; 

	widgets.descriptionMap[["s-Text_28", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_28", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Text", "s-Text_28"]; 

	widgets.descriptionMap[["s-Rectangle_9", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_9", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Rectangle_10", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Button dark", "s-Rectangle_10"]; 

	widgets.descriptionMap[["s-Input_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Input_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Input_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Input_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Input_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_5", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Input_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_6", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Text_29", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_29", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_29"]; 

	widgets.descriptionMap[["s-Text_30", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_30", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_30"]; 

	widgets.descriptionMap[["s-Text_31", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_31", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_31"]; 

	widgets.descriptionMap[["s-Text_32", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_32", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_32"]; 

	widgets.descriptionMap[["s-Text_33", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_33", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_33"]; 

	widgets.descriptionMap[["s-Text_34", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_34", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_34"]; 

	widgets.descriptionMap[["s-Text_35", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_35", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_35"]; 

	widgets.descriptionMap[["s-Text_36", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_36", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_36"]; 

	widgets.descriptionMap[["s-Text_37", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_37", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_37"]; 

	widgets.descriptionMap[["s-Input_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_7", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Text_38", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_38", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_38"]; 

	widgets.descriptionMap[["s-Text_39", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_39", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_39"]; 

	widgets.descriptionMap[["s-Text_40", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Text_40", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Title 1", "s-Text_40"]; 

	widgets.descriptionMap[["s-Category_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Select drop down", "s-Category_1"]; 

	widgets.descriptionMap[["s-Rectangle_11", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_11", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Payment form 2", "s-Group_9"]; 

	widgets.descriptionMap[["s-Image_12", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Chev Down", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_18", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Close icon", "s-Image_18"]; 

	widgets.descriptionMap[["s-Rectangle_12", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_10"]; 

	widgets.descriptionMap[["s-Rectangle_13", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_10"]; 

	widgets.descriptionMap[["s-Rectangle_14", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_10"]; 

	widgets.descriptionMap[["s-Rectangle_15", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_10"]; 

	widgets.descriptionMap[["s-Input_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_8", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Input field", "s-Input_8"]; 

	widgets.descriptionMap[["s-Image_13", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_13", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Chev Down", "s-Image_13"]; 

	widgets.descriptionMap[["s-Rectangle_16", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_12"]; 

	widgets.descriptionMap[["s-Rectangle_17", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_17", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_12"]; 

	widgets.descriptionMap[["s-Rectangle_18", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_18", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_12"]; 

	widgets.descriptionMap[["s-Rectangle_19", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_19", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Dropdown", "s-Group_12"]; 

	widgets.descriptionMap[["s-Input_9", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_9", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Input field", "s-Input_9"]; 

	widgets.descriptionMap[["s-Image_14", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_14", "6075582e-378c-4fdf-adac-6eee1c63827e"]] = ["Chev Down", "s-Image_14"]; 

	widgets.descriptionMap[["s-Rectangle_1", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_2", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "2126e8ba-dd41-46f5-a839-e6a07337c6cb"]] = ["Twitter", "s-Image_4"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Twitter", "s-Image_4"]; 

	widgets.descriptionMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rounded rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Subscribe form 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Subscribe form 2", "s-Group_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Button dark", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Paragraph 1", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle_1", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Ellipse_1", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["User circle icon", "s-Group_1"]; 

	widgets.descriptionMap[["s-Image_35", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_35", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["User icon", "s-Image_35"]; 

	widgets.descriptionMap[["s-Bg", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Title", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Title", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Paragraph", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Text_10", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_10", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Text_12", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_12", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Ellipse_2", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Image_36", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_36", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["User icon", "s-Image_36"]; 

	widgets.descriptionMap[["s-Text_13", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_13", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Text_14", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_14", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Ellipse_3", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Image_37", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_37", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["User icon", "s-Image_37"]; 

	widgets.descriptionMap[["s-Text_15", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_15", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Text_16", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_16", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Ellipse_4", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Team 1", "s-Team-1"]; 

	widgets.descriptionMap[["s-Image_38", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_38", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["User icon", "s-Image_38"]; 

	widgets.descriptionMap[["s-Image_6", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Chev Right", "s-Image_6"]; 

	widgets.descriptionMap[["s-Image_7", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Chev Left", "s-Image_7"]; 

	widgets.descriptionMap[["s-Rectangle_2", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_5", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_5", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Text_8", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Text_8", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Medium dark footer 1", "s-Group_2"]; 

	widgets.descriptionMap[["s-Image_3", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Facebook", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "cb0d28aa-9025-4e5d-93b8-b6a0f02f807a"]] = ["Twitter", "s-Image_4"]; 

	