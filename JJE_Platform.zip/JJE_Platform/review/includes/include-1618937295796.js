document.write("<script type='text/javascript' charset='utf-8' src='./resources/jim/javascript/jim-min.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/widgets/widgets-description.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scenarios/function-jim-links1618937295796.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/prototype-1618937295796.js'></script>");